/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.latemar.MOD1.RONCHETTI.DANIOTTI;

import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.control.Button;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.FlowPane;
import javafx.scene.layout.VBox;

/**
 * Classe astratta che definisce la casella. Questa è un VBox che contiene 
 * una figura e un FlowPane di bottoni.
 * @author Filippo
 */
public abstract class Casella extends VBox{
    
    protected Figure figure;
    protected FlowPane buttons;
    
    private Button c;
    
    /**
     * Costruttore per la classe casella. Ne setta le dimensioni, inizializza
     * il bottone C e ne implementa le funzionalità, come anche il FlowPane che
     * lo contiene; inizializza e costruisce la figura secondo il parametro
     * n passato. Inoltre inserisce il MouseEvent di figura cliccata.
     * @param n 1 per costruire un cerchio, 2 per costruire un triangolo,
     * altrimenti vuoto.
     */
    public Casella(int n){
        super();
        
        this.setMaxSize(Commons.CELLSIZE, Commons.CELLSIZE);
        this.setMinSize(Commons.CELLSIZE, Commons.CELLSIZE);
        this.setSpacing(15);
        
        figure = new Figure();
        
        switch(n){
            case 0:
                break;
            case 1:
                figure.addCircle();
                break;
            case 2:
                figure.addTriangle();
                break;
            default:
                figure.clear();
        }
        
        // Dichiarazione e implementazione logica del bottone C
        c = new Button("C");
        c.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                if(!figure.isClear()){
                    figure.clear();
                }
            }            
        });
        
        //Implementazione dell'evento casella
        this.addEventHandler(MouseEvent.MOUSE_CLICKED, new EventHandler(){
            @Override
            public void handle(Event event) {
                c.fireEvent(new ActionEvent());
            }            
        });
        
        buttons = new FlowPane(c);
        
        figure.setAlignment(Pos.CENTER);
        buttons.setAlignment(Pos.CENTER);
        
        this.getChildren().addAll(figure, buttons);
        
        this.setAlignment(Pos.CENTER);
        
    }
    
    /**
     * Metodo che rimuove la figura dalla casella se presente.
     */
    public void removeFigure(){
        if(!figure.isClear()){
            figure.clear();
        }
    }
    
    /**
     * Metodo che ritorna che figura è presente, secondo l'implementazione
     * del metodo della classe Figure.
     * @return 1 se cerchio, 2 se triangolo, 0 altrimenti.
     */
    public int whatFigure(){
        return figure.whatFigure();
    }
    
}
