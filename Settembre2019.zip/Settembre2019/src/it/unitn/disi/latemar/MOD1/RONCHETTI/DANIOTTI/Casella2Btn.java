/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.latemar.MOD1.RONCHETTI.DANIOTTI;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

/**
 * Definizione della Casella a 3 bottoni.
 * @author Filippo
 */
public class Casella2Btn extends Casella{
    
    private Button r;
    
    /**
     * Costruttore della Casella a 2 bottoni. Passa il parametro per la
     * costruzione della figura e inizializza, implementa e aggiunge al FlowPane
     * il bottone rimanente.
     * @param n 1 per costruire un cerchio, 2 per costruire un triangolo,
     * altrimenti vuoto.
     */
    public Casella2Btn(int n) {
        super(n);
        
        //Inizializzazione e implementazione di R
        r = new Button("R");
        r.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                figure.addRandomFigure();
            }            
        });
        
        buttons.getChildren().addAll(r);
        
    }
    
}
