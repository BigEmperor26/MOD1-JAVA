/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.latemar.MOD1.RONCHETTI.DANIOTTI;

import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.scene.control.Button;

/**
 * Definizione della Casella a 3 bottoni.
 * @author Filippo
 */
public class Casella3Btn extends Casella{
    
    private Button o;
    private Button t;
    
    /**
     * Costruttore della Casella a 3 bottoni. Passa il parametro per la
     * costruzione della figura e inizializza, implementa e aggiunge al FlowPane
     * i bottoni rimanenti.
     * @param n 1 per costruire un cerchio, 2 per costruire un triangolo,
     * altrimenti vuoto.
     */
    public Casella3Btn(int n) {
        super(n);
        
        //Inizializzazione e implementazione di O
        o = new Button("O");
        o.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                figure.addCircle();
            }            
        });
        
        //Inizializzazione e implementazione di T
        t = new Button("T");
        t.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                figure.addTriangle();
            }            
        });
        
        buttons.getChildren().addAll(o,t);
        
    }
    
}
