/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.latemar.MOD1.RONCHETTI.DANIOTTI;

import java.util.Optional;
import javafx.scene.Node;
import javafx.scene.control.Alert;
import javafx.scene.control.ButtonType;
import javafx.scene.layout.GridPane;

/**
 * Classe che gestisce la griglia di caselle, estende GridPane
 * @author Filippo
 */
public class CasellaGrid extends GridPane{
    
    /**
     * Costruttore per la Griglia. Ne setta le dimensioni, gli spazi tra elementi
     * e la popola con un numero di caselle dato.
     */
    public CasellaGrid(){
        
        this.setHgap(25);
        this.setVgap(25);
        
        
        for(int i = 0; i < Commons.GRIDSIZE; i++){
            for(int j = 0; j< Commons.GRIDSIZE; j++){
                boolean what = Commons.rand.nextBoolean();
                if(what){
                    this.add(new Casella3Btn(0), i, j);
                }else{
                    this.add(new Casella2Btn(0), i, j);
                }                
            }
        }
        
    }
    
    /**
     * Metodo che ritorna un elemento della griglia a una data colonna e una
     * data riga.
     * @param column Colonna dell'elemento desiderato.
     * @param row Riga dell'elemento desiderato.
     * @return Elemetno desiderato, come Node; cast necessario.
     */
    public Node getItemAt(int column, int row){
        for(Node e : this.getChildren()){
            try{
                if (GridPane.getRowIndex(e) == row &&
                    GridPane.getColumnIndex(e) == column){
                    return e;
                }
            }catch(NullPointerException ex){
            }
        }
        return null;
    }
    
    /**
     * Metodo che controlla la griglia e vede se ci sono colonne o righe con figure 
     * omogenee, ossia popolate da soli cerchi o triangoli. In caso affermativo,
     * mostra un messaggio a schermo indicante se è una colonna o riga, e indica
     * quale. In caso fossero presenti più colonne e/o righe omogenee, priorità
     * è data alle colonne, in particolare alla prima individuata.
     */
    public void check(){
        
        String a;
        String b;
        
        Casella e;
        Casella f;
        Casella g;
                
        // Controllo le colonne
        a = "colonna";
        for(int i = 0; i < Commons.GRIDSIZE; i++){
            e = (Casella) getItemAt(i, 0);
            f = (Casella) getItemAt(i, 1);
            g = (Casella) getItemAt(i, 2);
            
            if (e.whatFigure() == f.whatFigure() &&
                e.whatFigure() == g.whatFigure() &&
                e.whatFigure() != 0){
                
                b = Integer.toString(i+1);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("AVVISO");
                alert.setHeaderText("Tre!");
                alert.setContentText("Tre uguali in "+a+" "+b);
                Optional<ButtonType> result = alert.showAndWait();
                if(result.isPresent() && result.get() == ButtonType.OK){
                    alert.close();
                    return;
                }
            }
        }
        
        // Controllo le tighe
        a = "riga";
        for(int i = 0; i < Commons.GRIDSIZE; i++){
            e = (Casella) getItemAt(0, i);
            f = (Casella) getItemAt(1, i);
            g = (Casella) getItemAt(2, i);
            
            if (e.whatFigure() == f.whatFigure() &&
                e.whatFigure() == g.whatFigure() &&
                e.whatFigure() != 0){
                
                b = Integer.toString(i+1);
                Alert alert = new Alert(Alert.AlertType.INFORMATION);
                alert.setTitle("AVVISO");
                alert.setHeaderText("Tre!");
                alert.setContentText("Tre uguali in "+a+" "+b);
                Optional<ButtonType> result = alert.showAndWait();
                if(result.isPresent() && result.get() == ButtonType.OK){
                    alert.close();
                    return;
                }
            }
        }        
    }
    
}
