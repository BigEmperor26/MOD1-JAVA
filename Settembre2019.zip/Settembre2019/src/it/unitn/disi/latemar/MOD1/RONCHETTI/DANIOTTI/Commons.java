/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.latemar.MOD1.RONCHETTI.DANIOTTI;

import java.util.Random;

/**
 * Classe che riunisce costanti e strutture utili comuni, come ad esempio un
 * generatore di valori casuali.
 * @author Filippo
 */
public class Commons {
    
    /**
     * Larghezza della finestra.
     */
    public static final int SCENEWIDTH = 400;
    
    /**
     * Altezza della finestra.
     */
    public static final int SCENEHEIGHT = 450;
    
    /**
     * Dimensione della casella.
     */
    public static final int CELLSIZE = 100;
    
    /**
     * Dimensione della figura.
     */
    public static final int FIGURESIZE = 50;
    
    /**
     * Numero di elementi nella griglia NxN.
     */
    public static final int GRIDSIZE = 3;
    
    /**
     * Generatore di valori casuali.
     */
    public static final Random rand = new Random(System.currentTimeMillis());
    
    /**
     * Dimensione del raggio dei cerchi.
     */
    public static final int RADIUS = Commons.FIGURESIZE/2;
    
    /**
     * Vettore per la creazione di un triangolo equilatero.
     */
    public static final Double[] TRIANGLE = new Double[]{
        ((double)FIGURESIZE)/2.0, 0.0,
        0.0, ((double)FIGURESIZE),
        ((double)FIGURESIZE), ((double)FIGURESIZE)        
    };
    
}
