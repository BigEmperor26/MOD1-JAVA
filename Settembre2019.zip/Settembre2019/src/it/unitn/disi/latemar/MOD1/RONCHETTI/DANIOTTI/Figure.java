/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.latemar.MOD1.RONCHETTI.DANIOTTI;

import javafx.scene.layout.StackPane;
import javafx.scene.paint.Color;
import javafx.scene.shape.Circle;
import javafx.scene.shape.Polygon;
import javafx.scene.shape.Rectangle;
import javafx.scene.shape.Shape;

/**
 * Classe che definisce la figura e ne definisce il comportamento. Estende
 * StackPane per comodità di gestione, non c'è un effettivo bisogno di creare
 * overlays.
 * @author Filippo
 */
public class Figure extends StackPane{
    
    private Shape figure;
    
    private boolean clear;
    private boolean circle;
    private boolean tri;
    
    /**
     * Costruttore per la classe Figure. Ne setta le dimensioni, inizializza
     * i flags per identificare la figura e costruisce lo sfondo della figura 
     * vuota.
     */
    public Figure(){
        super();
        
        this.setMaxSize(Commons.FIGURESIZE, Commons.FIGURESIZE);
        this.setMinSize(Commons.FIGURESIZE, Commons.FIGURESIZE);
        
        clear = true;
        circle = false;
        tri = false;
        
        figure = new Rectangle(Commons.FIGURESIZE, Commons.FIGURESIZE);
        figure.setFill(Color.LIGHTGREY);
        figure.setStroke(Color.AQUAMARINE);
        
        this.getChildren().add(figure);
    }
    
    
    /**
     * Metodo che rimuove la figura e ridisegna lo sfondo, settando 
     * opportunemente i flags.
     */
    public void clear(){
        if(!clear){
            this.getChildren().clear();
            figure = new Rectangle(Commons.FIGURESIZE, Commons.FIGURESIZE);
            figure.setFill(Color.LIGHTGREY);
            figure.setStroke(Color.AQUAMARINE);

            clear = true;
            circle = false;
            tri = false;

            this.getChildren().add(figure);
        }        
    }
    
    /**
     * Metodo che aggiunge un cerchio, settandone opportunemente i flags.
     */
    public void addCircle(){
        if(!circle){
            this.getChildren().clear();
            figure = new Circle(Commons.RADIUS);
            figure.setFill(Color.YELLOW);
            figure.setStroke(Color.RED);

            clear = false;
            circle = true;
            tri = false;

            this.getChildren().add(figure);
        }        
    }
    
    /**
     * Metodo che disegna un triangolo, settandone opportunemente i flags.
     */
    public void addTriangle(){
        if(!tri){
            this.getChildren().clear();
            figure = new Polygon();
            ((Polygon)figure).getPoints().addAll(Commons.TRIANGLE);
            figure.setFill(Color.YELLOW);
            figure.setStroke(Color.RED);

            clear = false;
            circle = false;
            tri = true;

            this.getChildren().add(figure);    
        }
    }
    
    /**
     * Metodo che, casualmente, aggiunge o un triangolo o un cerchio, settando
     * opportunemente i flags.
     */
    public void addRandomFigure(){
        boolean what = Commons.rand.nextBoolean();
        this.getChildren().clear();
        if(what){
            this.getChildren().clear();
            figure = new Circle(Commons.RADIUS);
            figure.setFill(Color.YELLOW);
            figure.setStroke(Color.RED);

            clear = false;
            circle = true;
            tri = false;

            this.getChildren().add(figure); 
            
        }else{
            this.getChildren().clear();
            figure = new Polygon();
            ((Polygon)figure).getPoints().addAll(Commons.TRIANGLE);
            figure.setFill(Color.YELLOW);
            figure.setStroke(Color.RED);

            clear = false;
            circle = false;
            tri = true;

            this.getChildren().add(figure);  
            
        }
    }
    
    /**
     * Metodo che ritorna se è presente o meno una figura geometrica.
     * @return True se non è presente nessuna figura, false altrimenti.
     */
    public boolean isClear(){
        return clear;
    }
    
    /**
     * Metodo che ritorna quale figura è presente, se presente.
     * @return 1 se la figura presente è un cerchio, 2 se è un triangolo; se
     * nessuna figura è presente, ritorna 0. La scelta di tali valori è motivata
     * da una ricerca di consistenza, si veda il costruttore per la classe
     * casella per comprendere meglio.
     */
    public int whatFigure(){
        if(!isClear()){
            if(circle){
                return 1;
            }else{
                return 2;
            }
        }
        return 0;
    }
}
