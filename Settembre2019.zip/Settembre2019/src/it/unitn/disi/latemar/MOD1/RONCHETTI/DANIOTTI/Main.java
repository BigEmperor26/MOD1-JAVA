/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package it.unitn.disi.latemar.MOD1.RONCHETTI.DANIOTTI;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.Event;
import javafx.event.EventHandler;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyEvent;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.stage.Stage;

/**
 * Classe principale del progetto. Contiene l'inizializzazione delle strutture
 * grafiche, il loro posizionamento e il metodo main.
 * @author Filippo
 */
public class Main extends Application {
    
    private VBox root;
    private CasellaGrid grid;
    private HBox bottom;
    
    private Button clear;
    private Button check;
    
    /**
     * Costruttore per la classe Main. Inizializza il VBox e gli altri elementi
     * grafici, dichiara i bottoni del pannello inferiore e ne implementa le
     * funzionalità.
     */
    public Main(){
        
        root = new VBox();
        grid = new CasellaGrid();
        
        // Inizializzazione e implementazione del bottone CLEAR
        clear = new Button("Clear all");
        clear.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                for(int i = 0; i < Commons.GRIDSIZE; i++){
                    for(int j = 0; j< Commons.GRIDSIZE; j++){
                        Casella e = (Casella) grid.getItemAt(i, j);
                        e.removeFigure();
                    }   
                }
            }            
        });
        
        // Inizializzazione e implementazione del bottone CHECK
        check = new Button("Check");
        check.setOnAction(new EventHandler(){
            @Override
            public void handle(Event event) {
                grid.check();
            }            
        });
        
        // Associazione dei bottoni alla pressione dei tasti
        root.addEventHandler(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>(){
            @Override
            public void handle(KeyEvent event) {
                if(event.getCode() == KeyCode.A){
                    clear.fireEvent(new ActionEvent());
                }
            }        
        });
        
        root.addEventHandler(KeyEvent.KEY_PRESSED, new EventHandler<KeyEvent>(){
            @Override
            public void handle(KeyEvent event) {
                if(event.getCode() == KeyCode.C){
                    check.fireEvent(new ActionEvent());
                }
            }        
        });
        
        
        
        bottom = new HBox(clear, check);
        
        root.getChildren().addAll(grid, bottom);
    }
    
    /**
     * Metodo start
     * @param primaryStage 
     */
    @Override
    public void start(Stage primaryStage) {
       
        root.setAlignment(Pos.CENTER);
        grid.setAlignment(Pos.CENTER);
        bottom.setAlignment(Pos.CENTER);
        root.setSpacing(30);
        bottom.setSpacing(30);
        
        Scene scene = new Scene(root, Commons.SCENEWIDTH, Commons.SCENEHEIGHT);
        
        primaryStage.setTitle("TRE!");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        launch(args);
    }
    
}
